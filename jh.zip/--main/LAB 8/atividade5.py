class Onibus:
    def __init__(self, placa, nome_motorista, num_assentos):
        self.placa = placa
        self.nome_motorista = nome_motorista
        self.assentos = [False] * num_assentos

    def __len__(self):
        return len(self.assentos)

    def __getitem__(self, indice):
        if indice < 0 or indice >= len(self.assentos):
            raise IndexError(f"ESCOLHA UM VALOR ENTRE 0 E {len(self.assentos)-1}")
        return self.assentos[indice]

    def __setitem__(self, indice, valor):
        if indice < 0 or indice >= len(self.assentos):
            raise IndexError(f"ESCOLHA UM VALOR ENTRE 0 E {len(self.assentos)-1}")

        if not isinstance(valor, bool):
            raise TypeError("VALOR DEVE SER BOOLEANO (TRUE/FALSE)")

        self.assentos[indice] = valor

    def __str__(self):
        ocupados = self.assentos.count(True)
        livres = self.assentos.count(False)

        return (
            f"ÔNIBUS (PLACA: {self.placa}) - MOTORISTA: {self.nome_motorista}\n"
            f"ASSENTOS TOTAIS: {len(self.assentos)}\n"
            f"ASSENTOS OCUPADOS: {ocupados}\n"
            f"ASSENTOS LIVRES: {livres}\n"
        )

onibus = Onibus("ABC-1234", "Pedro Henrique Castrado", 10)
print(len(onibus))
onibus[0] = True
print(onibus)


